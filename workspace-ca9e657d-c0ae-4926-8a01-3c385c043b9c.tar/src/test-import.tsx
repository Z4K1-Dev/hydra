// Test file to check imports
import { SimpleGoogleAnalyticsPlugin } from '/home/z/my-project/src/plugins/google-analytics/simple';

console.log('SimpleGoogleAnalyticsPlugin imported:', SimpleGoogleAnalyticsPlugin);